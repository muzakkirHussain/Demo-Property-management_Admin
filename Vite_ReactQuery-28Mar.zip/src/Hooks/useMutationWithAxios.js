// import { useMutation } from "react-query";
// import axios from "axios";

// const useMutationWithAxios = () => {
//   const mutateWithAxios = async (method, url, data, token) => {
//     try {
//       let response;
//       switch (method.toLowerCase()) {
//         case "post":
//           response = await axios.post(url, data, {
//             headers: {
//               Authorization: `Bearer ${token}`,
//             },
//           });
//           break;
//         case "put":
//           response = await axios.put(url, data, {
//             headers: {
//               Authorization: `Bearer ${token}`,
//             },
//           });
//           break;
//         case "delete":
//           response = await axios.delete(url, {
//             headers: {
//               Authorization: `Bearer ${token}`,
//             },
//           });
//           break;
//         default:
//           throw new Error("Invalid HTTP method");
//       }
//       return response.data;
//     } catch (error) {
//       throw new Error(error.response.data.message);
//     }
//   };

//   return useMutation(mutateWithAxios);
// };

// export default useMutationWithAxios;

import { useMutation } from "react-query";
import axios from "axios";

const useMutationWithAxios = () => {
  const token = "2josjdf92nu9dm";
  const mutation = useMutation(async (method, url, data) => {
    try {
      let response;
      switch (method.toLowerCase()) {
        case "post":
          response = await axios.post(url, data, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          break;
        case "put":
          response = await axios.put(url, data, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          break;
        case "delete":
          response = await axios.delete(url, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          break;
        default:
          throw new Error("Invalid HTTP method");
      }
      return response.data;
    } catch (error) {
      throw new Error(error.response.data.message);
    }
  });

  const { isPending, isError, isSuccess, mutate } = mutation;

  return { isPending, isError, isSuccess, mutate };
};

export default useMutationWithAxios;
