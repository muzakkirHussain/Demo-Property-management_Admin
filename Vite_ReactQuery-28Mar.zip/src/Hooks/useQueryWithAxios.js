import { useQuery } from "react-query";
import axios from "axios";

const token = "2josjdf92nu9dm";
const useQueryWithAxios = (key, url, params = {}) => {
  return useQuery(key, async () => {
    const response = await axios.get(url, {
      params,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data;
  });
};

export default useQueryWithAxios;
