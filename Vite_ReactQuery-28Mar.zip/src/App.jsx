import { useState } from "react";
import "./App.scss";
import useQueryWithAxios from "./Hooks/useQueryWithAxios";

function App() {
  // This is for GET
  const { isLoading, isError, data, error } = useQueryWithAxios(
    "exampleQueryKey",
    "https://api.example.com/data"
  );
  // This is for PUT, PATCH, DELETE
  const {
    isPending,
    isError: homeIsError,
    isSuccess,
    mutate,
  } = useMutationWithAxios();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await mutate("post", "https://api.example.com/users", userData);
      // Reset form data after successful mutation
      setUserData({
        username: "",
        email: "",
        password: "",
      });
    } catch (error) {
      console.error("Error creating user:", error);
    }
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
  return (
    <div>
      <h2>Create User</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username:</label>
          <input
            type="text"
            name="username"
            value={userData.username}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={userData.email}
            onChange={handleChange}
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={userData.password}
            onChange={handleChange}
          />
        </div>
        <button type="submit" disabled={isPending}>
          {isPending ? "Creating User..." : "Create User"}
        </button>
        {isError && <p>Error creating user.</p>}
        {isSuccess && <p>User created successfully!</p>}
      </form>
    </div>
  );
}

export default App;
